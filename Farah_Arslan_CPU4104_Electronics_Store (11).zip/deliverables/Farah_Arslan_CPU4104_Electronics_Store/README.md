# NovaVolt Electronics

**Student:** Farah Arslan  
**Module:** CPU4104-20C Web Development  
**Project category:** Electronics Store

## Project summary

NovaVolt Electronics is a responsive e-commerce website for smartphones, laptops and accessories. It was made with the three technologies taught on the module:

- HTML for the page structure
- CSS for the design and responsive layout
- JavaScript and the DOM for interactive features

No framework, external library, database or backend is used.

## How to open the website

1. Extract the ZIP file.
2. Keep all folders in the same structure.
3. Open `index.html` in Google Chrome, Microsoft Edge or Firefox.
4. The file redirects to the home page in the `pages` folder.

For the most reliable testing, the folder can also be opened with the Visual Studio Code **Live Server** extension.

## Main features

- Home page with a hero area and featured products
- Products page with 12 electronics
- Search, category filter and price sorting
- Separate product detail page
- Add-to-cart buttons
- Cart saved in the browser with `localStorage`
- Increase, decrease and remove cart items
- Automatically calculated subtotal, delivery and total
- Checkout and contact form validation
- Responsive navigation for mobile screens
- Accessible keyboard focus, labels, alternative text and colour contrast
- Page titles, descriptions and social-sharing metadata
- Simple local page-view counter for learning purposes

## Folder structure

```text
Farah_Arslan_CPU4104_Electronics_Store/
├── index.html
├── pages/
│   ├── index.html
│   ├── products.html
│   ├── product.html
│   ├── cart.html
│   ├── about.html
│   └── contact.html
├── css/style.css
├── js/script.js
├── media/images/
├── evidence/
├── docs/
└── README.md
```

## Beginner explanation of the JavaScript

The `products` array stores the information for each item. JavaScript reads this list and creates the product cards on the page. When a button is clicked, an event listener runs a small function. The cart is stored as item numbers and quantities in `localStorage`, so it remains after the page is refreshed. The cart page reads that saved information and calculates the total.

## Testing

The site was checked at desktop (1440 px), tablet (768 px) and mobile (390 px) widths. The checks covered navigation, all 12 products, search, filters, product details, cart quantity changes, totals and form validation. Evidence images are stored in the `evidence` folder and a testing record is stored in `docs`.

## GitHub submission steps

1. Create a new GitHub repository, for example `farah-novavolt-electronics`.
2. Upload the contents of this folder without changing the structure.
3. Check that every page and image is present.
4. Copy the repository link into the Moodle submission area.
5. Do not upload passwords or personal information.

## Academic integrity note

Farah should read the code, practise the presentation and be able to explain the product list, DOM rendering, cart storage, form validation and media queries in her own words.
